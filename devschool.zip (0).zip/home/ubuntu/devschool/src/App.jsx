import { useState } from 'react'
import Header from './components/layout/Header.jsx'
import Footer from './components/layout/Footer.jsx'
import LanguageSelector from './components/pages/LanguageSelector.jsx'
import InteractiveSlides from './components/pages/InteractiveSlides.jsx'
import PracticeExercises from './components/pages/PracticeExercises.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Code, BookOpen, Trophy, Users, CheckCircle, Star, Play, Search, Award, Clock } from 'lucide-react'
import './App.css'

function App() {
  const [currentPage, setCurrentPage] = useState('home')

  const renderPage = () => {
    switch (currentPage) {
      case 'languages':
        return <LanguageSelector />
      case 'slides':
        return <InteractiveSlides />
      case 'exercises':
        return <PracticeExercises />
      default:
        return <HomePage setCurrentPage={setCurrentPage} />
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      {renderPage()}
      <Footer />
    </div>
  )
}

function HomePage({ setCurrentPage }) {
  return (
    <>
      {/* Hero Section */}
      <section id="inicio" className="bg-gradient-to-br from-blue-50 to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-8">
              <div className="bg-primary rounded-full p-6 shadow-lg">
                <Code className="h-16 w-16 text-white" />
              </div>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              <span className="text-primary">DevSchool</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-700 mb-8 max-w-4xl mx-auto leading-relaxed">
              Aprenda qualquer linguagem de programação com mais de{' '}
              <span className="font-bold text-primary">1.000 slides</span> e{' '}
              <span className="font-bold text-accent">2.000 exercícios</span> por apenas{' '}
              <span className="font-bold text-2xl text-green-600">R$10</span>
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                onClick={() => setCurrentPage('languages')}
                className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
              >
                Começar Agora
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setCurrentPage('slides')}
                className="border-primary text-primary hover:bg-primary hover:text-white px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-200"
              >
                Ver Demo
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">1000+</div>
                <div className="text-gray-600">Slides Interativos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent mb-2">2000+</div>
                <div className="text-gray-600">Exercícios Práticos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">R$10</div>
                <div className="text-gray-600">Preço Único</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Experimente Nossa Plataforma
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Veja como é fácil e divertido aprender programação com a DevSchool
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg transform hover:scale-105" onClick={() => setCurrentPage('slides')}>
              <CardHeader>
                <div className="bg-blue-500 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-xl text-center">Slides Interativos</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center mb-4">
                  Aprenda com explicações claras e exemplos práticos
                </p>
                <Button variant="outline" className="w-full">
                  <Play className="h-4 w-4 mr-2" />
                  Ver Demo
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg transform hover:scale-105" onClick={() => setCurrentPage('exercises')}>
              <CardHeader>
                <div className="bg-green-500 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Trophy className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-xl text-center">Exercícios Práticos</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center mb-4">
                  Pratique com exercícios interativos e feedback instantâneo
                </p>
                <Button variant="outline" className="w-full">
                  <Code className="h-4 w-4 mr-2" />
                  Praticar
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg transform hover:scale-105" onClick={() => setCurrentPage('languages')}>
              <CardHeader>
                <div className="bg-purple-500 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-xl text-center">Múltiplas Linguagens</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center mb-4">
                  Escolha entre 12+ linguagens de programação
                </p>
                <Button variant="outline" className="w-full">
                  <Search className="h-4 w-4 mr-2" />
                  Explorar
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Linguagens Section */}
      <section id="linguagens" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Todas as Linguagens em Um Só Lugar
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Escolha qualquer linguagem de programação e comece a aprender hoje mesmo
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {[
              { name: 'Python', color: 'bg-yellow-500' },
              { name: 'JavaScript', color: 'bg-yellow-400' },
              { name: 'Java', color: 'bg-red-500' },
              { name: 'C/C++', color: 'bg-blue-600' },
              { name: 'PHP', color: 'bg-purple-600' },
              { name: 'Ruby', color: 'bg-red-600' },
              { name: 'Go', color: 'bg-cyan-500' },
              { name: 'Rust', color: 'bg-orange-600' },
              { name: 'Swift', color: 'bg-orange-500' },
              { name: 'Kotlin', color: 'bg-purple-500' },
              { name: 'C#', color: 'bg-purple-700' },
              { name: 'TypeScript', color: 'bg-blue-500' }
            ].map((lang, index) => (
              <div key={index} className="bg-white rounded-lg border border-gray-200 p-6 text-center hover:shadow-lg transition-all duration-200 transform hover:scale-105 cursor-pointer">
                <div className={`w-12 h-12 ${lang.color} rounded-lg mx-auto mb-3 flex items-center justify-center`}>
                  <Code className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900">{lang.name}</h3>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button 
              onClick={() => setCurrentPage('languages')}
              className="bg-primary hover:bg-primary/90 text-white px-8 py-3 text-lg font-semibold rounded-lg"
            >
              Ver Todas as Linguagens
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Por Que Escolher a DevSchool?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A forma mais eficiente e acessível de aprender programação
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-primary rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Conteúdo Didático</h3>
              <p className="text-gray-600">Slides interativos com explicações claras e progressivas</p>
            </div>

            <div className="text-center">
              <div className="bg-accent rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Trophy className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Exercícios Práticos</h3>
              <p className="text-gray-600">Mais de 2.000 exercícios para praticar e fixar o aprendizado</p>
            </div>

            <div className="text-center">
              <div className="bg-purple-500 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Tradução Completa</h3>
              <p className="text-gray-600">Comandos traduzidos para português para facilitar o aprendizado</p>
            </div>

            <div className="text-center">
              <div className="bg-green-500 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <CheckCircle className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Preço Acessível</h3>
              <p className="text-gray-600">Acesso completo a todas as linguagens por apenas R$10</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              O Que Nossos Alunos Dizem
            </h2>
            <p className="text-xl text-gray-600">
              Depoimentos reais de quem já transformou sua carreira
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Maria Silva',
                role: 'Desenvolvedora Frontend',
                content: 'A DevSchool me ajudou a aprender JavaScript de forma prática e eficiente. Em 2 meses já estava criando meus primeiros projetos!',
                rating: 5
              },
              {
                name: 'João Santos',
                role: 'Analista de Dados',
                content: 'O curso de Python foi perfeito para minha transição de carreira. As explicações são claras e os exercícios muito bem estruturados.',
                rating: 5
              },
              {
                name: 'Ana Costa',
                role: 'Estudante de Engenharia',
                content: 'Por R$10 tive acesso a um conteúdo que vale muito mais. Recomendo para qualquer pessoa que quer aprender programação.',
                rating: 5
              }
            ].map((testimonial, index) => (
              <Card key={index} className="bg-white">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonial.content}"</p>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Comece Hoje Mesmo
          </h2>
          <p className="text-xl text-gray-600 mb-12">
            Acesso completo a todas as linguagens e recursos por um preço único
          </p>

          <div className="bg-gradient-to-br from-primary to-purple-600 rounded-2xl p-8 text-white shadow-2xl max-w-md mx-auto">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4">Curso Completo</h3>
              <div className="text-5xl font-bold mb-2">R$10</div>
              <div className="text-lg opacity-90 mb-6">Pagamento único</div>
              
              <ul className="text-left space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3 text-green-300" />
                  Todas as linguagens de programação
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3 text-green-300" />
                  Mais de 1.000 slides interativos
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3 text-green-300" />
                  Mais de 2.000 exercícios práticos
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3 text-green-300" />
                  Comandos traduzidos para português
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3 text-green-300" />
                  Acesso vitalício
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3 text-green-300" />
                  Certificados de conclusão
                </li>
              </ul>

              <Button className="w-full bg-white text-primary hover:bg-gray-100 font-bold py-3 text-lg rounded-lg transition-all duration-200 transform hover:scale-105">
                Pagar via Pix
              </Button>
              
              <p className="text-sm opacity-75 mt-4">
                Chave Pix: devpyhsite@gmail.com
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default App

